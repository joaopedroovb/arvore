package arvoredecisao;
public class TreeNode {
  TreeNode esquerdaNode;
  int info;
  String texto;
  TreeNode direitaNode;

  public TreeNode(int nodeInfo, String texto){
    this.info = nodeInfo;
    this.texto = texto;
    esquerdaNode = direitaNode = null;
  }

  public void insereNode(int insertValue, String texto){
  //ARVORE DE BUSCA BINARIA - MENORES A ESQUERDA E MAIORES A DIREITA
    if (insertValue < info){
      if (esquerdaNode == null)
       esquerdaNode = new TreeNode(insertValue, texto);
      else
       esquerdaNode.insereNode(insertValue, texto);
    }
    else if (insertValue > info){
      if (direitaNode == null)
	direitaNode = new TreeNode(insertValue, texto);
      else
	direitaNode.insereNode(insertValue, texto);
    }
  }
}
