package arvoredecisao;

public class ArvoreDecisao {
    public static void main(String[] args) {
        Tree dec = new Tree();
        dec.insereNode(10, "Febre?");
        dec.insereNode(5, "Dor no corpo?");
        dec.insereNode(2, "Atestado!!! - Dengue");
        dec.insereNode(7, "Atestado!!! - Virose");
        dec.insereNode(12, "Diagnostico: Preguiça!");
        dec.inOrder();
        System.out.println("\nPerguntas");
        dec.imprimePerguntas();
        System.out.println("\nRespostas");
        dec.imprimeRespostas();
        System.out.println("\nSim");
        dec.imprimeSim();
    }
    
}
