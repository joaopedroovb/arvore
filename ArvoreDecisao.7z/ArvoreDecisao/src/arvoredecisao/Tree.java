package arvoredecisao;

public class Tree {
    private TreeNode raiz; 
  public Tree(){
    raiz = null;  
  }
  public void insereNode(int insertValue, String texto){
    if (raiz == null)
      raiz = new TreeNode(insertValue, texto);
    else
      raiz.insereNode(insertValue, texto);
  }

  public void preOrder(){
    pre(raiz);   
  }
  private void pre(TreeNode node){
    if (node == null)
      return ;
    System.out.print(node.info + " , ");
    pre(node.esquerdaNode);
    pre(node.direitaNode);
  }

  public void inOrder(){
    in(raiz);   
  }
  private void in(TreeNode node){
    if (node == null)
      return ;
    in(node.esquerdaNode);
    System.out.print(node.info + " , ");
    in(node.direitaNode);
  }
  
  //INTERNO - TEM FILHOS - 1
  public void imprimePerguntas(){
    pergunta(raiz);   
  }
  
  private void pergunta(TreeNode node){
    if (node == null)
      return ;
    
    pergunta(node.esquerdaNode);
    if (node.esquerdaNode != null || node.direitaNode != null)
        System.out.print(node.texto + " , ");
    pergunta(node.direitaNode);
  }
  
  //EXTERNO - NÃO TEM FILHOS - 2
  public void imprimeRespostas(){
    resposta(raiz);   
  }
  
  private void resposta(TreeNode node){
    if (node == null)
      return ;
    
    pergunta(node.esquerdaNode);
    if (node.esquerdaNode == null && node.direitaNode == null)
        System.out.print(node.texto + " , ");
    resposta(node.direitaNode);
  }
  
  //3
  
  public void imprimeSim(){
    sim(raiz, 'R');   
  }
  
  private void sim(TreeNode node, char direcao){
    if (node == null)
      return ;
    
    pergunta(node.esquerdaNode);
    if (node.esquerdaNode == null && node.direitaNode == null && direcao == 'S')
        System.out.print(node.texto + " , ");
    sim(node.direitaNode, 'S');
    sim(node.esquerdaNode, 'S');
  }
  
}
